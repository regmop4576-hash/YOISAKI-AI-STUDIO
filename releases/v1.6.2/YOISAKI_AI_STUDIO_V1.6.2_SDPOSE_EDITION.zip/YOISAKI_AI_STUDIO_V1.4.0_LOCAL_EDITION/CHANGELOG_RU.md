# Текущий выпуск: v1.6.2 SDPose Edition

Сайт и движок: v1.6.2. Добавлен только препроцессор позы SDPose-OOD в существующий ControlNet; Canny, Depth, OpenPose Classic, очередь, галерея, LoRA и интерфейс AMBER CORE не менялись. Полный отчёт: `YOISAKI_V1.6.2_SDPOSE_REPORT.md`.

- Панель ControlNet, тип OpenPose: «Препроцессор позы» — OpenPose Classic (по умолчанию) или SDPose-OOD (стилизованные, аниме, фурри, сложные позы). Карта — OpenPose-18 тела для того же OpenPose ControlNet.
- Движок: `inference/sdpose.py` — SDPose-Body (`teemosliang/SDPose-Body`), fp16 на GPU только на время подготовки карты, затем полная выгрузка (ссылки, gc, `torch.cuda.empty_cache()`); без mmpose/mmcv и без CLIP text encoder.
- Протокол: необязательное поле `preprocessor` (`openpose` | `sdpose`) в предобработке и в `controlnet_config`; `/health` объявляет `capabilities.sdpose`; сайт 1.6.2 принимает только движок 1.6.2.
- Понятные ошибки: недоступные веса, нехватка RAM/VRAM, NaN, поза не найдена; остальные режимы продолжают работать.

# Выпуск v1.6.1 ControlNet Stability Fix

Сайт и движок: v1.6.1. Только исправления ошибок по независимому аудиту v1.6.0; архитектура, интерфейс AMBER CORE и зависимости не менялись. Полный отчёт: `YOISAKI_V1.6.1_STABILITY_REPORT.md`.

- AUD-001: Strength/Start/End приводятся к float перед Diffusers (Strength 0/1/2 больше не вызывают TypeError).
- AUD-019 (найдено при исправлении): `from_pipe()` больше не переводит общие fp16-модули SDXL и ControlNet в fp32.
- AUD-004: Canny загружает официальный fp16-вариант safetensors.
- AUD-003: ControlNet не копируется GPU→RAM перед освобождением (нужны замеры на T4).
- AUD-002: история и галерея хранят SHA-256 карты вместо base64; миграция данных v1.6.0 без потерь; state.json не перезаписывается без изменений.
- AUD-006: предобработка ControlNet возобновляется ответом PENDING, без обрыва по таймауту браузера/Cloudflare.
- AUD-007: ограниченная очистка завершённых записей движка (более 100 заданий за сессию).
- AUD-008 / AUD-012: бинарные карты Canny; надёжная отбраковка однородной глубины.
- AUD-009 / AUD-015: понятные причины отказа GPU; синхронизированы версии, документация и устаревшие тесты.

# Выпуск v1.6.0 ControlNet

Отчёт: `YOISAKI_CONTROLNET_V1.6.0_CHANGELOG.md` в корне проекта.

## История прежних выпусков

# Изменения v1.5.4

- `server/history.mjs` — общие terminal статусы и retention 50.
- `server/storage.mjs` — постоянный pruning при загрузке и сериализованной записи, без изменения других данных.
- `server/app.mjs` — individual/bulk history API, проверка CONNECTION_LOST перед удалением, history metadata для UI, отдельные сведения о версиях, совместимый reconnect ACK.
- `server/release.mjs` — версия сайта и compatibility metadata.
- `src/components/JobHistory.tsx` — компактная история, корзина, подтверждаемая очистка, сохранение активных задач.
- `src/components/Generator.tsx` — подключение истории и защита от устаревших polling-ответов.
- `src/lib/engine/direct.ts` — типы metadata сайта и совместимости.
- `src/components/Shell.tsx`, `SettingsModal.tsx`, `src/app/engine/page.tsx` — только отдельные truthful версии сайта/движка.
- `server/index.mjs`, `scripts/service.mjs`, package.json/package-lock.json — версия сайта 1.5.4.
- Новые `tests/history.test.mjs`, `tests/history-browser.mjs`; пересобраны dist и integrity manifest; обновлена документация.

Python engine/Colab 1.5.3, long prompts, LoRA, Regional algorithm, CPU Offload, RAM FIX, галерея, пресеты и настройки не менялись. Внешняя логика генерации не заменялась тестовыми изображениями.
