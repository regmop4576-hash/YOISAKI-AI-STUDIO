export const WEBSITE_VERSION='1.6.2';
export const COMPATIBLE_ENGINE_FAMILY='1.6.2';
export function engineCompatibility(info){
 if(!info)return 'NOT_CONNECTED';
 return info.engine==='YOISAKI_ENGINE'&&info.engine_version==='1.6.2'&&info.capabilities?.controlnet===true&&info.capabilities?.sdpose===true?'COMPATIBLE':'UNVERIFIED';
}
