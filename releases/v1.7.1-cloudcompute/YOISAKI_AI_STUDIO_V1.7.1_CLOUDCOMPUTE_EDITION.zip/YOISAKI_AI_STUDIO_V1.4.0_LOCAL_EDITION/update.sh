#!/usr/bin/env bash
set -euo pipefail
APP_DIR=$(cd -- "$(dirname -- "$0")" && pwd -P)
if [[ $# -ne 1 ]]; then echo 'Обновление: ./update.sh /путь/к/новому_архиву.zip'; exit 1; fi
ARCHIVE=$(realpath -- "$1")
if ! command -v unzip >/dev/null; then
  if command -v pkg >/dev/null; then pkg install -y unzip; else echo 'Нужна программа unzip.'; exit 1; fi
fi
STAGE=$(mktemp -d "$(dirname "$APP_DIR")/.yoisaki-update.XXXXXX")
trap 'rm -rf -- "$STAGE"' EXIT
# Validate every name before extraction; do not allow absolute paths or traversal.
while IFS= read -r entry; do
 case "$entry" in /*|*../*|*\\*) echo 'Небезопасный путь в архиве.'; exit 1;; esac
done < <(unzip -Z1 "$ARCHIVE")
if unzip -Z -l "$ARCHIVE" | awk '$1 ~ /^l/ {found=1} END {exit !found}'; then
 echo 'Архив с символическими ссылками не поддерживается.'; exit 1
fi
unzip -q "$ARCHIVE" -d "$STAGE"
NEW_DIR="$STAGE/YOISAKI_AI_STUDIO_V1.4.0_LOCAL_EDITION"
if [[ ! -f "$NEW_DIR/server/index.mjs" ]]; then echo 'В архиве не найдена локальная редакция приложения.'; exit 1; fi
if find "$NEW_DIR" -type l | read -r _; then echo 'Архив с символическими ссылками не поддерживается.'; exit 1; fi
(cd "$NEW_DIR" && node scripts/verify-package.mjs)
bash "$APP_DIR/stop.sh"
BACKUP="${APP_DIR}.backup-$(date +%Y%m%d-%H%M%S)"
mv -- "$APP_DIR" "$BACKUP"
if ! mv -- "$NEW_DIR" "$APP_DIR"; then mv -- "$BACKUP" "$APP_DIR"; echo 'Обновление отменено, восстановлена предыдущая версия.'; exit 1; fi
(cd "$APP_DIR" && bash install.sh)
echo 'Обновлено. Пользовательские данные сохранены отдельно в домашней папке Termux.'
echo "Предыдущая версия: $BACKUP"
echo "Запуск: $APP_DIR/start.sh"
