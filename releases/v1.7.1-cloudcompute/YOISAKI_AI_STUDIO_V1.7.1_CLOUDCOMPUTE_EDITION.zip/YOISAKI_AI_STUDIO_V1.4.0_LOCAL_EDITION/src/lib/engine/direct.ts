'use client';
import {create} from 'zustand';
import type {LiveModel} from './live';
import {localApi} from '../local-api';
export type DirectStatus='OFFLINE'|'CONNECTING'|'READY'|'BUSY'|'LOADING'|'ERROR';
type EngineInfo={gpu_name:string|null;vram_total_mb:number|null;vram_available_mb:number|null;engine_version:string;state:DirectStatus};
type Snapshot={website_version?:string;compatible_engine_family?:string;compatibility?:string;url:string;state:DirectStatus;info:EngineInfo|null;models:LiveModel[];error:string};
type State=Snapshot&{token:string;set:(x:Partial<Snapshot>)=>void;connect:(raw:string)=>Promise<void>;disconnect:()=>Promise<void>;refresh:(models?:boolean)=>Promise<void>};
export const useDirect=create<State>((set)=>({url:'',token:'',state:'OFFLINE',info:null,models:[],error:'',set:x=>set(x),
 disconnect:async()=>{try{set(await localApi<Snapshot>('/api/gpu/disconnect',{method:'POST'}))}catch(e){set({error:(e as Error).message})}},
 connect:async raw=>{set({state:'CONNECTING',error:''});try{set(await localApi<Snapshot>('/api/gpu/connect',{method:'POST',body:JSON.stringify({url:raw})}))}catch(e){set({state:'ERROR',info:null,error:(e as Error).message});throw e}},
 refresh:async(models=false)=>{try{set(await localApi<Snapshot>('/api/gpu/status'+(models?'?models=1':'')))}catch(e){set({state:'OFFLINE',info:null,error:(e as Error).message})}}
}));
// Compatibility signature retains existing components; credentials now live only in Node memory.
export async function directFetch<T>(_url:string,_token:string,path:string,init:RequestInit={}):Promise<T>{return localApi<T>('/api/gpu/'+path,init)}
export async function imageFromDirect(_url:string,_token:string,id:string,index:number){return '/api/gallery/'+encodeURIComponent(id+'_'+index)+'/file'}
